// import javax.swing.*;
// import java.awt.*;
// import java.io.BufferedReader;
// import java.io.IOException;
// import java.io.InputStreamReader;
import java.util.Random; // imports random
// import java.util.Scanner;
// import java.util.Timer;
// import java.awt.event.KeyEvent;
// import java.util.TimerTask;
// import java.awt.Graphics;
// import java.awt.Graphics2D;


public class main { // main

    public static void generateAliens(int difficulty) { // this method generates the black aliens that are coming from the mother ship

        Random rng = new Random(); // sets up a new random
        int num =rng.nextInt(difficulty)+1; // sets the difficulty (number of aliens in the first phasse of the game)
//        if(num == 0){
//            for (int i = 0; i < aliens.length; i++) {
//
//                if (aliens[i]== null)
//                {
////                    System.out.println("a");
//                    num =  rng.nextInt(difficulty);
//                    Aliens alien = new Aliens(num,0);
//                    aliens[i] = alien;
//                    break;
//
//                }
//
//            }
//        }
        Aliens[] newAliens = new Aliens[aliens.length+num]; // alien array that creates them temperery and set the new array (new aliens) bigger
        for (int i = 0; i < aliens.length; i++) { // copies array information
            if (aliens[i] != null) {
                newAliens[i] = aliens[i];
            }
        }
        for (int i = 0; i < num; i++) { // sets the stating positon of the aliens
            int x = rng.nextInt(10);
            x = x*80+100;
            try {

                newAliens[aliens.length+i] = new Aliens(x,aliens[0].alienPosition.getY()+50); // sets the starting alien position relative to the mother ship
            }
            catch (Exception e){}
        }
        aliens = newAliens; // final copy back

    }

    public static void printScreen(String[][] screen){ 

        for (int i = 0; i < screen.length; i++) {
            for (int j = 0; j < screen[i].length; j++) {
                System.out.print(screen[i][j]);
            }
            System.out.println("");
        }

    }

    public static boolean runGame(){
        for (int i = 0; i < aliens.length; i++) {
         if(aliens[i]!= null)
         {
             if (aliens[i].getAlienPosition().getY()==7)
                 return false;
         }
        }
        return true;
    }

    public static String[][] eraseScreen(){
        String[][] baseScreen= new String[9][11];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 11; j++) {
                baseScreen[i][j]="[]";
            }
        }
        for (int k = 0; k < 11; k++) {
            baseScreen[8][k] = "^^";
        }
//
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]", "[]"},
//                {"^^", "^^", "^^", "^^", "^^", "^^", "^^", "^^", "^^", "^^", "^^"}
//        };
        return baseScreen;
    }

    
    public static void printGame(String[][] screen,Ship ship,Aliens[] Aliens){

        screen[ship.getShipPosition().getY()][ship.getShipPosition().getX()]= "><";

        for (int i = 0; i < Aliens.length; i++) {
            if (aliens[i]!= null)
                screen[aliens[i].getAlienPosition().getY()][aliens[i].getAlienPosition().getX()]= "pq";

        }

        for (int i = 0; i < ship.getBullets().length; i++) {
            if (ship.getBullets()[i]!=null){
                screen[ship.getBullets()[i].getY()][ship.getBullets()[i].getX()] = "!!";

            }

        }

        printScreen(screen);



    }
    public static void generateRecs(){ // generrate a rectangle for whatever purpese nedded (aliens)
        Rectengles[] recs =new Rectengles[aliens.length+1];
        recs[0] = ship.getRectengle();
        for (int i = 0; i < aliens.length; i++) {
            if(aliens[i]!=null)
                recs[i+1]=aliens[i].getRectengle();
        }
        rectengles = recs;
    }

    public static void moveAliens(){ // changes the position of the aliens
        for (int i = 0; i < aliens.length; i++) {
            if(aliens[i]!=null) {
                aliens[i].move();

            }
        }
    }

    public static boolean allMyFriendsAreDead(){ // checks if game ended (all aliens dead)
        for (int i = 0; i < aliens.length; i++) {
            if (aliens[i]!=null)
                return false;
        }
        return true;
    }
    public static boolean isDead(){ // checks if the ship is dead

        for (int i = 0; i < aliens.length; i++) {
            if (aliens[i]!=null)
            if (aliens[i].getAlienPosition().getY()+aliens[i].getAlienPosition().getWidth()/2>=ship.getShipPosition().getY()) // checks if an alien moved behind the ship (or is on)
                return true;

        }
        return false;
    }
 
    // public static String [][] screen = eraseScreen();
    public static Ship ship = new Ship(475, 600); // crates the ship (player) sets the x and y of the ship so we can draw it right
    public static Aliens[] aliens = new Aliens[1]; // creates the main array of the aliens
    public static Rectengles[] rectengles = new Rectengles[10]; // creates the main array of the rectangles
    public static int SPaint = 0; // sets a way to determant if a string is needed to be drawn on the screen (for win or lose)

    public static void main(String[] args) throws InterruptedException { // main
//        KeyEvent keys = new KeyEvent()


        AlienBoss boss = new AlienBoss(450,50,50);  // creates the boss
        boss.setMovmentMultiplier(1); // sets the movement range of the aliens
        aliens[0] = boss; // sets the boss at the alien array

        Window win = new Window(1000,650);

        win.setFocusable(true);
        win.addKeyListener(new KeyListner(ship));





        int a = 3;
        int delay = 140; // delay between spawns (for us)
        int delay1 = 10; // delay between spawns (for us)
        boolean endGame = false; // checks if game ended
        Random rng = new Random(); // new random
        while (runGame()) { // game loop

            generateRecs(); // generate recs
            win.repaint(); // paint things on screen
            ship.readyShip(aliens); // sets the elegibility to move as true and checks if hit alien

            Thread.sleep(delay); // set delay

            moveAliens(); // changes the position of the aliens

            if(aliens[0]== null&& !allMyFriendsAreDead()&&!endGame){ // if mother ship and all aliens died and the game didnt end
                endGame = true;
                aliens =new Aliens[1];
                ship.setBullets(new Position[0]); // changes bullet position
                aliens[0] = new AlienBoss(500,100,100,100,20); // makes new alien boss
                aliens[0].setMovmentMultiplier(10); // ups the speed of the aaliens movement (just the boss)
            } 

            else if(aliens[0]!= null&&!endGame) // if mother ship and all aliens didnt die and the game didnt end
            {
                if (delay1 == 1){ // if delay between spawns of aliens passed
                    generateAliens(8); // generate alliens
                    a =rng.nextInt(4);
                    delay1 = (25+a); // new delay to next spawn
                }
                delay1--;
            }
            else if(aliens[0]!= null){ // if boss alien alive

                aliens[0].setCanShoot(true); // can shoot
            }
            else
            {
                SPaint = 1;
                win.repaint(); // paint window
                break;
            }
            if(isDead()){ // checks for lose
                SPaint = 2;
                win.repaint(); // paint window
                break;
            }
            aliens[0].readyAlien();

            for (int i = 0; i < aliens.length; i++) { // for every alien:

                if (aliens[i]!=null){ // checks if exist
                    if (aliens[i].isCanShoot())


                        aliens[i].shoot(); // alien shoot

                }

            }






        }
    }
}

