import java.util.Random;

public class Aliens { // constractor: Alien class

    private enum MovingDiraction{
        left,right
    }
    protected Position[] bullets = new Position[0]; // bullet array
    protected boolean canShoot; // checks if eligible for shooting
//    private MovingDiraction movingDiraction;
    protected int movingDiraction; // direction of that the alien movement
    protected int movmentMultiplier = 7; // walk range untill goes to the other direction
    protected Position alienPosition; // alien position (position class)
    protected boolean isNull; // checks if eligible for moving
    private String location = "Space-Invader.jpg"; // the picture of the alien (not used)


    public Aliens(){// sets new position
        this.alienPosition = new Position();
    }

    public Aliens(int x,int y){// sets position specificly by x and y parameters, moving starting direction left and eligible for moving
        this.alienPosition = new Position(x,y,50,50);

//        this.movingDiraction = MovingDiraction.left;
        this.movingDiraction = -5;
        this.isNull =false;
    }
    /**
     * sets parameters for an alien, moving starting direction left and eligible for moving
     * @param x // x alien
     * @param y // y alien
     * @param width // width of the alien
     * @param length // height (length) of the alien
     */
    public Aliens(int x,int y,int width,int length){
        this.alienPosition = new Position(x,y,width,length);

//        this.movingDiraction = MovingDiraction.left;
        this.movingDiraction = -5;
        this.isNull =false;
    }

    public Position[] getBullets() { // get brllets position
        return bullets;
    }

    public void readyAlien(){

        for (int i = 0; i < bullets.length; i++) { // do for each bullet on the screen:

            if (bullets[i] != null) {
                bullets[i].setY(bullets[i].getY() + 20); // move bullet alien down the screen

                if ( bullets[i] != null) { // if the aliens win (kill the ship) tp to the ship (easier to check a win for us)
                    if (isBulletHitPlayer(bullets[i], main.ship)) {
                        this.alienPosition = main.ship.getShipPosition();
                    }
                }
            }
//                System.out.println("x="+this.getBullets()[i].getX()+"y="+this.getBullets()[i].getY());
        }

    }

    /**
     * shoot method for the aliens
     */
    public void shoot(){
        Random rng = new Random(); 
        int num = rng.nextInt(3); // random shoot speed
        if (num ==0) {
            Position[] newBullets = new Position[bullets.length + 1]; // adds a bullet on the screen
            for (int i = 0; i < bullets.length; i++) {
                newBullets[i + 1] = bullets[i];
            }
            newBullets[0] = new Position(alienPosition.getX(), alienPosition.getY() + alienPosition.getWidth() / 2);
            bullets = newBullets;
        }
    }
    /**
     * returns if the ship is hit
     * @param pos position of the bullet
     * @param player // a player so we can know his coordinates
     * @return
     */
    private boolean isBulletHitPlayer(Position pos,Ship player){ 
                return player !=null
                &&pos!=null
                && (player.getShipPosition().getX()+player.getShipPosition().getWidth()/2)>=pos.getX()
                && (player.getShipPosition().getX()-player.getShipPosition().getWidth()/2)<=pos.getX()
                && (player.getShipPosition().getY()+player.getShipPosition().getLength()/2)>=pos.getY()
                && (player.getShipPosition().getY()-player.getShipPosition().getLength()/2)<=pos.getY();
    }

    public boolean isCanShoot() { // checks for elegibility for shooting
        return canShoot;
    }

    
    public void setCanShoot(boolean canShoot) { // sets a knew state for the param canShoot (boolean)
        this.canShoot = canShoot;
    }

    /**
     * sets the new position of the alien
     * @param position alien position
     */
    public Aliens(Position position){
        this.alienPosition = new Position(position.getX(), position.getY());
        this.isNull =false;
    }

    public Position getAlienPosition() { // gets the alen position
        if(!isNull)
        return alienPosition;
        return null;
    }

    public void move(){ // move (change) alien position by moving direction
        if(!isNull) {

            if (movingDiraction == 5) {
                alienPosition.setY(alienPosition.getY() + movmentMultiplier*2); // down left
                movingDiraction = -5;
            }
          else if (movingDiraction ==0) {
                alienPosition.setY(alienPosition.getY() + movmentMultiplier*2); // down right
            }
          else if (movingDiraction <= -1)
                alienPosition.setX(alienPosition.getX() + movmentMultiplier*2); // left
//
            else if (movingDiraction >=1)
                alienPosition.setX(alienPosition.getX() - movmentMultiplier*2); // right
            else {}
            movingDiraction++;
        }
    }
    public int getMovmentMultiplier() { // get MovmentMultiplier param
        return movmentMultiplier;
    }

    public void setMovmentMultiplier(int movmentMultiplier) { // set MovmentMultiplier as new int
        this.movmentMultiplier = movmentMultiplier;
    }
    public Aliens gotHit(){
        return null;
    }
    public int getHp() {
        return 1;
    }

    public boolean isNull() {
        return isNull;
    }


    @Override
    public String toString() { // to string (for checking the game)
        return "aliens{" +
                "alienPosition=" + alienPosition +
                '}';
    }

    public Picture getPicture(){ // not used (get picture position)
        int num = this.alienPosition.getX()-(this.alienPosition.getWidth())/2;
        int num1 = this.alienPosition.getY()-this.alienPosition.getLength()/2;
        return new Picture(num,num1,this.location);

    }

    public Rectengles getRectengle(){ // get rectangle (enemies) position
        return new Rectengles(this.alienPosition.getX()-(this.alienPosition.getWidth())/2,this.alienPosition.getY()-this.alienPosition.getLength()/2,this.alienPosition.getWidth(),this.getAlienPosition().getLength());

    }

}
