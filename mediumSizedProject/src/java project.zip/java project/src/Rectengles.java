public class Rectengles { // rectangle information class
    private int x,y,width,length; // prameters: x pos, y pos, width rect, length (height) rect


    public int getX() { // get x param
        return x;
    }

    public void setX(int x) { // set x param
        this.x = x;
    }

    public int getY() { // get y param
        return y;
    }

    public void setY(int y) { // set y param
        this.y = y;
    }

    public int getWidth() { // get width param
        return width;
    }

    public void setWidth(int width) { // set width param
        this.width = width;
    }

    public int getLength() { // get length param
        return length;
    }

    public void setLength(int length) { // set length param
        this.length = length;
    }

    /**
     * sets all params
     * @param x x pos
     * @param y y pos
     * @param width width rect
     * @param length length rect
     */
    public Rectengles(int x, int y, int width, int length){
        this.x = x;
        this.y = y;
        this.length = length;
        this.width =width;
    }



}
