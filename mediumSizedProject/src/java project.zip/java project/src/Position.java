public class Position {
    private int x; // x cordinate
    private int y; // y cordinate
    private int width; // width rectangle or picture
    private int length; // height (length) rectangle or picture

    /**
     * sets all params exept width and length (sets as 0)
     * @param x // x pos
     * @param y // y pos
     */
    public Position(int x,int y){
        this.x = x;
        this.y = y;
        this.width =0;
        this.length =0;
    }

    public Position(){ // sets params o
        this.x = 0;
        this.y = 0;
        this.width =0;
        this.length =0;
    }

    /**
     * sets all params 
     * @param x // x pos
     * @param y // y pos
     * @param width // width
     * @param length // height (length)
     */
    public Position(int x,int y,int width,int length){
        this.x = x;
        this.y = y;
        this.width =width;
        this.length =length;
    }

    public int getLength() { // get length param
        return length;
    }

    public void setLength(int length) { // set length param
        this.length = length;
    }

    public int getWidth() { // get width param
        return width;
    }
    public void setWidth(int width) { // set width param
        this.width = width;
    }

    public int getX() { // get x param
        return x;
    }

    public int getY() { // get y param
        return y;
    }

    public void setX(int x) { // set x param
        this.x = x;
    }

    public void setY(int y) { // set y param
        this.y = y;
    }

    @Override
    public String toString() { // checking (for us)
        return "position{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
