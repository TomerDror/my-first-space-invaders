import javax.swing.ImageIcon;
import javax.swing.*;

import java.awt.*;

public class myPanel extends JPanel { // prints graphics on the window
    private int width; // width of window
    private int height; // height of window

    // set image
    // private Image xWing;
    // private Image Invader;

    private Picture[] pictures = new Picture[0]; // picture array (not used)

    /**
     * sets all params and the preffered size of the window
     * @param width // width window
     * @param height // height window
     */
    public myPanel(int width, int height) {

        this.width = width;
        this.height = height;

        // add here all the diffrent pictures u want
        // this.BackgroundImage = new ImageIcon("Background.png").getImage();
        //  this.xImage = new ImageIcon("Ex.png").getImage();
        // this.oImage = new ImageIcon("OO.png").getImage();

        // this.xWing = new ImageIcon("shipImage.jpeg").getImage();
        // this.Invader = new ImageIcon("Space-Invaders.shep.jpeg").getImage();

        this.setPreferredSize(new Dimension(width, height));

    }

    public void paint(Graphics g) { // paints things on the screen from this function

        Graphics2D g2d = (Graphics2D) g; // new graphics


        // g2d.drawImage(this.image, x, y, null);

        paintRecs(g2d); // recs paint function

        paintString(g2d); // paint strings function   
        // if you want to refresh the screen go main



    }
    private void paintString(Graphics g2d){ // paints win/lose declerations on the screen
        String str = "";
        if (main.SPaint == 1){ // checks for win
            str = "You Win!!! (how?)";
        }

        else if (main.SPaint == 2){ // checks for lose
            str = "You lost";
        }
        
        Font font = new Font("SansSerif",Font.ROMAN_BASELINE,60); // make new font and size of text
        g2d.setColor(Color.MAGENTA); // text color
        g2d.setFont(font); // sets font
        g2d.drawString(str, 40, 90); // draws string (str)
    }

    private void paintRecs(Graphics g2d){ // paint rectangles
        Rectengles[] recs= main.rectengles; // makes rectangle array (for enemies,player...)

        for (int i = 0; i < recs.length; i++) { // checks/does for every rectangle:
            if (recs[i]!=null)
                g2d.fillRect(recs[i].getX(),recs[i].getY(),recs[i].getWidth(),recs[i].getLength()); // print filled rectangle (x,y,width,height)
        }
        try {
            for (int i = 0; i < main.ship.getBullets().length; i++) { // checks/does for every ship bullet:
                if (main.ship.getBullets()[i] != null) ; // checks if bullet exist
                g2d.setColor(Color.RED); // sets color as red
                g2d.fillRect(main.ship.getBullets()[i].getX(), main.ship.getBullets()[i].getY(), 5, 5); // prints filled rectangle (x,y,width,height)


            }

        }
        catch(Exception e){}

        try {
            for (int i = 0; i < main.aliens[0].getBullets().length; i++) { // checks/does for every alien bullet:
                if (main.aliens[0].getBullets()[i] != null) ; // checks if bullet exist
                g2d.setColor(Color.RED); // sets color as red
                g2d.fillRect(main.aliens[0].getBullets()[i].getX(), main.aliens[0].getBullets()[i].getY(), 5, 5); // prints filled rectangle (x,y,width,height)
            }
        }
        catch(Exception e){}

    }


    public void paintImages(Graphics2D g2d){ // paints images (not used)
        for (int i = 0; i < pictures.length; i++) { // for every picture:
            if(pictures[i]!=null) // checks if picture exist

                g2d.drawImage(pictures[i].getPicture(),pictures[i].getX(),pictures[i].getY(),null); // prints image (x,y,width,height,abserver)



        }
    }

    /**
     * adds pictures to the picture array (not used)
     * @param picture new picture
     */
    public void addPicture(Picture picture){

        Picture[] newPictures = new Picture[pictures.length+1];
        for (int i = 0; i < pictures.length; i++) {
            if (pictures[i] != null) {
                newPictures[i] = pictures[i];
            }
        }
        newPictures[pictures.length]= picture;
        this.pictures = newPictures;
    }

    /**
     * removes pictures from the picture array (not used)
     * @param picture new picture
     */
    public void removePicture(Picture picture){
        for (int i = 0; i < pictures.length; i++) {
            if ((pictures[i]!=null)&&
                (pictures[i].getX()==picture.getX())&&
                (pictures[i].getY()==picture.getY())&&
                (pictures[i].getLocation()==picture.getLocation())) {

                pictures[i] = null;

            }

        }
        int count=0;
        for (int i = 0; i < pictures.length; i++) {
            if (pictures[i]==null){
                count-=-1;
            }
        }
        Picture[] newPictures =new Picture[pictures.length-count];

        int pos=0;
        for (int i = 0; i < pictures.length; i++) {
            if (pictures[i]!=null){
                newPictures[pos] = pictures[i];
                pos++;
            }
        }
    }




}
