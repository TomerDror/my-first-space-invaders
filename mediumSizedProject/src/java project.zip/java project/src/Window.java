import java.awt.*;
import javax.swing.*;

public class Window extends JFrame{ // the game window

    private myPanel panel; // panel (print things on screen fromthere)

    private int width; // win width
    private int height; // win height (length)

    /**
     * set param
     * @param width win width
     * @param height win height (length)
     */
    public Window(int width, int height) {
        this.width = width;
        this.height = height;


        myPanel panel = new myPanel(this.width, this.height);  // new panel

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit window on pressing the X button on the right up of the window
        // this.setSize(width, height);
        this.add(panel); // adds the prints from panel to the window
        this.pack();
        // this.setLocationRelativeTo(null);
        this.setVisible(true); // sets the things on the window visible

    }
    
}
