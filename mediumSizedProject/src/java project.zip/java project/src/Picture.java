import javax.swing.*;
import java.awt.*;

public class Picture { // picture information class


    private int x; // x pos
    private int y; // y pos
    private String location; // url

    /**
     * sets all params
     * @param x x pos
     * @param y y pos
     * @param location url
     */
    public Picture(int x,int y, String location){
        this.x = x;
        this.y = y;
        this.location = location;
    }

    public String getLocation() { // get location param
        return this.location;
    }
    public Image getPicture(){ // creates image using url
        return  new ImageIcon(location).getImage();
    }

    public void setLocation(String location) { // set location param
        this.location = location;
    }

    public int getY() { // get y param
        return y;
    }

    public void setY(int y) { // set y param
        this.y = y;
    }

    public int getX() { // get x param
        return x;
    }

    public void setX(int x) { // set x param
        this.x = x;
    }
}
