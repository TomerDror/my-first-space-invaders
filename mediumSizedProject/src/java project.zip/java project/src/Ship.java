import java.awt.event.KeyEvent;

public class Ship {

    private Position shipPosition; // ship position
    private boolean canShoot = false; // checks for elegibility for shooting
    private boolean canMove = false; // checks for elegibility for moving
    private Position[] bullets = new Position[1]; // bullet postion of the ship 
    private String location = "shipImage.jpeg"; // ship image (not used)


    public Ship(){ // sets new position
        this.shipPosition = new Position();
    }

    /**
     * sets sarting parameters for a ship (player)
     * @param x // x alien
     * @param y // y alien
     */
    public Ship(int x,int y){
        this.shipPosition = new Position(x,y,50,50);

    }

    /**
     * sets parameters for a ship (player)
     * @param x // x alien
     * @param y // y alien
     */
    public Ship(Position Position){
        this.shipPosition = new Position(Position.getX(),Position.getY());
    }


    public Position getShipPosition() { // gets shipPosition param
        return shipPosition;
    }

    public void setShipPosition(Position shipPosition) { // sets ship position
        this.shipPosition = shipPosition;
    }

    public boolean isCanShoot() { // checks for elegibility to shoot
        return canShoot;
    }

    public void setCanShoot(boolean canShoot) { // sets canShoot param
        this.canShoot = canShoot;
    }


    public void moveLeft(){ // moves ship left

        if (shipPosition.getX()>=100&&canMove) // checks elegibility to move left
        this.shipPosition.setX(this.shipPosition.getX()-40); // sets new position
        canMove = false; // sets the elegibility to move back to false
    }


    public void moveRight(){

        if (shipPosition.getX()<=900&&canMove) // checks elegibility to move right
        this.shipPosition.setX(this.shipPosition.getX()+40); // sets new position
        canMove = false; // sets the elegibility to move back to false
    }

    /**
     * sets the elegibility to move as true and checks if hit alien
     * @param aliens alien array
     */
    public void readyShip(Aliens[] aliens){
        canMove = true;
        //moves object in array



        for (int i = 0; i < bullets.length; i++) { //checks and does for every bullet:

            if(bullets[i]!=null ) { // if exsists
//                System.out.println("x="+this.getBullets()[i].getX()+"y="+this.getBullets()[i].getY());
                bullets[i].setY(bullets[i].getY()-20 );// move down

                for (int j = 0; j < aliens.length; j++) { // checks for every alien
                    if(aliens[j]!=null&&bullets[i]!=null){ // if exists 
                        if (isBulletHitAlien(aliens[j],bullets[i])) // if bullet hit alien
                        {
                            aliens[j]= aliens[j].gotHit();
                            bullets[i] = null;
                        }
                    }
                }
//                System.out.println("x="+this.getBullets()[i].getX()+"y="+this.getBullets()[i].getY());
            }
        }


        canShoot = true;
    }

    /**
     * checks if a bullet of a player hit an alien
     * @param alien alien
     * @param bullet position of the bullet
     * @return
     */
    private boolean isBulletHitAlien(Aliens alien, Position bullet) {

        return  alien !=null
                &&bullet!=null
                && (alien.getAlienPosition().getX()+alien.alienPosition.getWidth()/2)>=bullet.getX()
                && (alien.getAlienPosition().getX()-alien.alienPosition.getWidth()/2)<=bullet.getX()
                && (alien.getAlienPosition().getY()+alien.alienPosition.getLength()/2)>=bullet.getY()
                && (alien.getAlienPosition().getY()-alien.alienPosition.getLength()/2)<=bullet.getY();
    }

    public void shoot(){ // makes the ship shoot

        if (canShoot) { // checks if able to shoot
            canShoot = false;

            Position[] newBullets = new Position[bullets.length+1]; // adds an array that is bigger by one space fron the bullets
            for (int i = 0; i < bullets.length; i++) { 
                newBullets[i+1] = bullets[i]; //copies the old bullets to the new array
            }
            bullets = newBullets; // copy back
            bullets[0] = new Position(shipPosition.getX(), shipPosition.getY()-25 ); // sets new bullet
        }

    }


    public void setBullets(Position[] bullets) { // set bullets param
        this.bullets = bullets;
    }

    public Position[] getBullets() { // gets bullet param
        return bullets;
    }



    public Picture getPicture(){ // gets the position of the image of the ship (not used)
        int num = this.shipPosition.getX()-(this.shipPosition.getWidth())/2;
        int num1 = this.shipPosition.getY()-this.shipPosition.getLength()/2;
        return new Picture(num,num1,this.location);

    }
    public Rectengles getRectengle(){ // gets the position of the rectangle of the ship
        return new Rectengles(this.shipPosition.getX()-(this.shipPosition.getWidth())/2,this.shipPosition.getY()-this.shipPosition.getLength()/2,this.shipPosition.getWidth(),this.shipPosition.getLength());

    }
}
