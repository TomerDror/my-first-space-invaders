public class AlienBoss extends Aliens{ // alien boss class

    private boolean canShoot; // elegibility to shoot
    private int hp; // boss hp (healph points)

    public AlienBoss(){ // sets inheritance with Aliens class, elegibility to shoot as false, and the hp 5
        super();
        this.canShoot = false;
        this.hp = 5;

    }

    /**
     * sets sarting parameters for a alien boss 
     * @param x // x boss alien
     * @param y // y boss alien
     * @param hp // hp boss alien
     */
    public AlienBoss(int x,int y,int hp){
        super(x,y,700,50);
        this.canShoot = false;
        this.hp = hp;
    }

    /**
     * sets sarting parameters for a alien boss 
     * @param x // x boss alien
     * @param y // y boss alien
     * @param width // width boss alien
     * @param length // height (length) boss alien
     * @param hp // hp boss alien
     */
    public AlienBoss(int x,int y,int width,int length,int hp){
        super(x,y,width,length);
        this.canShoot = true;
        this.hp = hp;
    }
    @Override
    public int getHp() { // gets hp param
        return hp;
    }


    public void setHp(int hp) { // sets hp param
        if(!isNull)
        this.hp = hp;
    }

    @Override
    public AlienBoss gotHit() { // checks if boss alien got hit
        if(this.hp > 1) {
            setHp(getHp() - 1); // removes 1 hp
            return this;
        }
        return null;

    }
//    @Override
//    public void move(){
//        if(!isNull) {
//
//            if (movingDiraction == 5) {
//                alienPosition.setY(alienPosition.getY() + 2);
//                movingDiraction = -5;
//            }
//            else if (movingDiraction ==0) {
//                alienPosition.setY(alienPosition.getY() + 2);
//            }
//            else if (movingDiraction <= -1)
//                alienPosition.setX(alienPosition.getX() + 5);
////
//            else if (movingDiraction >=1)
//                alienPosition.setX(alienPosition.getX() - 5);
//            else {}
//            movingDiraction++;
//        }
//    }


}
