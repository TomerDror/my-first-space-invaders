import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyListner implements KeyListener { // key listner
    Ship ship = null;
    public KeyListner(Ship ship){
        this.ship = ship; // ship

    }
    @Override
    public void keyTyped(KeyEvent e) { // key typed (not used)

    }

    @Override
    public void keyPressed(KeyEvent e) { // checks if key is pressed

        int key = e.getKeyCode();


        if (key == KeyEvent.VK_A) { // if input 'A' move left
            ship.moveLeft();
        }

        if (key == KeyEvent.VK_D) { // if input 'D' move right
            ship.moveRight();
        }

        if (key == KeyEvent.VK_S){ // if input 'S' shoot
            ship.shoot();

        }
    }

    @Override
    public void keyReleased(KeyEvent e) { // key realise
    }
}
